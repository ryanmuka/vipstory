To create a config file:
Use the php storylook.php -g command.
Add a minimum of 20 goals for best results.